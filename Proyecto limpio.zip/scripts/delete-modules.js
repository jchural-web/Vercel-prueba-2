import fs from 'fs';
import path from 'path';

const dirsToDelete = [
  'app/atencion-cliente',
  'app/gestion-comercial',
  'app/correos',
  'app/analitica-ventas',
  'app/control-operativo',
  'app/tickets-asistencia',
  'app/gestion-tickets'
];

function removeDir(dirPath) {
  if (fs.existsSync(dirPath)) {
    fs.readdirSync(dirPath).forEach(file => {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        removeDir(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
    });
    fs.rmdirSync(dirPath);
    console.log(`Deleted: ${dirPath}`);
  }
}

console.log('Starting cleanup...');
dirsToDelete.forEach(dir => {
  try {
    removeDir(dir);
  } catch (err) {
    console.error(`Error deleting ${dir}:`, err.message);
  }
});
console.log('Cleanup complete!');
