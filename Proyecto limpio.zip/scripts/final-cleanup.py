import os
import shutil

# List of directories to remove
dirs_to_remove = [
    "/app/atencion-cliente",
    "/app/analitica-ventas",
    "/app/correos",
    "/app/gestion-comercial",
    "/app/gestion-tickets",
    "/app/control-operativo",
    "/app/tickets-asistencia"
]

for directory in dirs_to_remove:
    try:
        if os.path.exists(directory):
            shutil.rmtree(directory)
            print(f"✓ Eliminado: {directory}")
        else:
            print(f"✗ No encontrado: {directory}")
    except Exception as e:
        print(f"✗ Error eliminando {directory}: {str(e)}")

print("\n✓ Limpieza completada")
