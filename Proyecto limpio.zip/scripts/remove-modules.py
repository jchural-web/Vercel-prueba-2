#!/usr/bin/env python3
import os
import shutil

# Módulos a eliminar
modules_to_delete = [
    '/app/atencion-cliente',
    '/app/analitica-ventas',
    '/app/correos',
    '/app/gestion-comercial',
    '/app/gestion-tickets',
    '/app/control-operativo',
    '/app/tickets-asistencia'
]

print("Iniciando eliminación de módulos...")

for module_path in modules_to_delete:
    if os.path.exists(module_path):
        try:
            shutil.rmtree(module_path)
            print(f"✓ Eliminado: {module_path}")
        except Exception as e:
            print(f"✗ Error eliminando {module_path}: {e}")
    else:
        print(f"- No existe: {module_path}")

print("\nEliminación completada!")
