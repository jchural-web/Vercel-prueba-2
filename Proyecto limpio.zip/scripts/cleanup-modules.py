import os
import shutil

modules_to_delete = [
    'app/atencion-cliente',
    'app/analitica-ventas',
    'app/correos',
    'app/gestion-comercial',
    'app/gestion-tickets',
    'app/control-operativo',
    'app/tickets-asistencia'
]

print("🗑️  Iniciando eliminación de módulos innecesarios...\n")

for module_path in modules_to_delete:
    full_path = os.path.join(os.getcwd(), module_path)
    
    if os.path.exists(full_path):
        try:
            shutil.rmtree(full_path)
            print(f"✓ Eliminado: {module_path}")
        except Exception as e:
            print(f"✗ Error al eliminar {module_path}: {str(e)}")
    else:
        print(f"⚠ No existe: {module_path}")

print("\n✓ Limpieza completada correctamente")
print("\nMódulos restantes:")
print("  - app/page.tsx (Inicio)")
print("  - app/planificacion-operaciones/ (Planificación)")
print("  - Infraestructura global (components, hooks, etc.)")
