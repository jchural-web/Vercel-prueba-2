#!/bin/bash
# Copy agenda/[id]/page.tsx to agenda-general/[id]/page.tsx
cp /app/planificacion-operaciones/gestion-docente/agenda/\[id\]/page.tsx /app/planificacion-operaciones/gestion-docente/agenda-general/\[id\]/page.tsx
