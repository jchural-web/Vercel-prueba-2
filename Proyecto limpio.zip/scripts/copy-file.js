import fs from 'fs';
import path from 'path';

const sourceFile = '/app/planificacion-operaciones/gestion-docente/agenda/[id]/page.tsx';
const targetFile = '/app/planificacion-operaciones/gestion-docente/agenda-general/[id]/page.tsx';

// Read the source file
const content = fs.readFileSync(sourceFile, 'utf-8');

// Write to target file
fs.writeFileSync(targetFile, content, 'utf-8');

console.log('File copied successfully');
